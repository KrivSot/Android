package com.example.sqliteapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
    }

    public void ZobrazitZnacky(View v) {
        Intent ZobrazitZnacky = new Intent(MainActivity.this, Znacky.class);
        startActivity(ZobrazitZnacky);
    }
    public void ZobrazitModel(View v) {}
    public void Pridat(View v) {}
    public void Edit(View v) {}
    public void Search(View v) {}
}