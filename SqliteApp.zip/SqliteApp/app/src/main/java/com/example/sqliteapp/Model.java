package com.example.sqliteapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Model extends AppCompatActivity {

    String car;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        setContentView(R.layout.modely_layout);
        this.car = intent.getStringExtra("Auto");
        ListView ls = findViewById(R.id.modelList);
        registerForContextMenu(ls);
        Databaze db = new Databaze(getApplicationContext());
        ArrayAdapter<String> aa = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, db.GetAllModel(car));
        ls.setAdapter(aa);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if (v.getId()==R.id.modelList) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.menu_list, menu);
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        String key = ((TextView) info.targetView).getText().toString();
        Databaze db = new Databaze(getApplicationContext());
        switch(item.getItemId()) {
            case R.id.details:
                //add details
                return true;
            case R.id.edit:
                Intent edit = new Intent(Model.this, edit.class);
                edit.putExtra("Model", key);
                edit.putExtra("Znacka",car);
                edit.putExtra("Modelt",true);
                startActivityForResult(edit,1);
                return true;
            case R.id.delete:
                db.DeleteModel(car,key);
                db.close();
                ArrayAdapter<String> aa = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, db.GetAllModel(car));
                ListView ls = findViewById(R.id.modelList);
                ls.setAdapter(aa);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    public void Zpet(View v)
    {
        finish();
    }

    public void add(View v)
    {
        Intent pridatZnacky = new Intent(Model.this, add.class);
        pridatZnacky.putExtra("Auto",false);
        pridatZnacky.putExtra("typAuta",car);
        startActivityForResult(pridatZnacky,1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)  {
        super.onActivityResult(requestCode, resultCode, data);
        Databaze db = new Databaze(getApplicationContext());
        ArrayAdapter<String> aa = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, db.GetAllModel(car));
        ListView ls = findViewById(R.id.modelList);
        ls.setAdapter(aa);
        db.close();
    }
}
