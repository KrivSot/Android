package com.example.sqliteapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import static android.text.InputType.TYPE_CLASS_TEXT;

public class add extends AppCompatActivity {

    boolean auto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add);
        Intent intent = getIntent();
        this.auto = intent.getBooleanExtra("Auto",true);
        EditText id = findViewById(R.id.IdEditText);
        Button button = findViewById(R.id.ButtonPridat);
        button.setOnClickListener(clickListener);
        if(this.auto) {

            Databaze db = new Databaze(getApplicationContext());
            int posledniid = db.getPosledniIdAuta(false);
            int chybejiciid = db.FindMissingNumberA(posledniid);
            id.setText(String.valueOf(chybejiciid));
            db.close();
        }
        else{
            EditText name = findViewById(R.id.NameEditText);
            id.setFocusable(true);
            id.setFocusableInTouchMode(true);
            id.setInputType(TYPE_CLASS_TEXT);
            id.setText("Nazev Modelu");
            name.setText(intent.getStringExtra("typAuta"));
            name.setFocusable(false);
            name.setFocusableInTouchMode(false);
        }
    }

    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
    public void onClick(View v) {
            Intent resultIntent = new Intent();
            String[] autos;
            EditText idEt = findViewById(R.id.IdEditText);
            EditText nameEt = findViewById(R.id.NameEditText);
            Databaze db = new Databaze(getApplicationContext());
            if (auto) {

                resultIntent.putExtra("test", "test");
                if (String.valueOf(idEt.getText()) != null && String.valueOf(nameEt.getText()) != null) {
                    if (!db.existAuto(String.valueOf(nameEt.getText()))) {
                        autos = new String[]{String.valueOf(idEt.getText()), String.valueOf(nameEt.getText())};
                        db.pridatAuto(autos);
                        String[] models = new String[]{"1",String.valueOf(nameEt.getText())};
                        db.pridatModel(models);
                        db.close();
                        setResult(RESULT_OK, resultIntent);
                        finish();
                    } else {
                        Toast.makeText(getApplicationContext(), "Auto už je v databázi", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Jedna ze zadaných hodnot je prázdná!", Toast.LENGTH_SHORT).show();
                    db.close();
                }
            }
            else{
                if(db.existAuto(String.valueOf(nameEt.getText())))
                {
                    autos = new String[]{String.valueOf(idEt.getText()), String.valueOf(nameEt.getText())};
                    db.pridatModel(autos);
                    db.close();
                    setResult(RESULT_OK,resultIntent);
                    finish();
                }
                else{
                    Toast.makeText(getApplicationContext(), "Tato znacka v databazi neexistuje!", Toast.LENGTH_SHORT).show();
                    db.close();
                }
            }
        }
    };

    public void Zrusit(View v)
    {
        this.finish();
    }
}
