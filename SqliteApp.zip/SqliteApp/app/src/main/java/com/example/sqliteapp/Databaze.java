package com.example.sqliteapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import static java.lang.String.valueOf;

public class Databaze extends SQLiteOpenHelper {
    public static final String KEY_ID_AUTO = "id_auto";
    public static final String KEY_ID_MODEL = "id_model";
    public static final String KEY_NAZEV = "nazev";
    public static final String KEY_MODEL = "modelId";
    public static final String KEY_TYP_MOTORU = "typ_motoru";
    private static final String DATABASE_NAME = "auta.db";
    private static final String DATABASE_TABLE_AUTO = "auto";
    private static final String DATABASE_TABLE_MODEL = "model";
    private static final String KEY_ZNACKA = "znacka";
    private static final String SPOTREBA = "spotreba";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_CREATE_AUTO = "create table auto (id_auto integer primary key autoincrement," +
            "nazev text not null)";
    private static final String TABLE_CREATE_MODEL = "create table model (modelId text not null, znacka text not null)";

    //create table model (model text not null, znacka text not null, typ_motoru String not null, pocet_valcu integer, spotreba double, ostatní text)";
    SQLiteDatabase db;

    public Databaze(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE_AUTO);
        db.execSQL(TABLE_CREATE_MODEL);
        this.db = db;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query_nazvy = "DROP TABLE IF EXISTS auto";
        String query_poznamky = "DROP TABLE IF EXISTS model";
        db.execSQL(query_nazvy);
        db.execSQL(query_poznamky);
        this.onCreate(db);
    }

    //zjisti posledni id v tabulce auto a pokud se parametr rovna true tak vrati id nasledujici po poslednim
    public int getPosledniIdAuta(boolean pridani){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM auto",null);
        c.moveToLast();
        String s = c.getString(1);
        Integer i = Integer.valueOf(c.getInt(0));
        if(pridani){return i+1;}
        else{return i;}
    }

    public void pridatAuto(String[] hodnoty){
        db = this.getWritableDatabase();
        if(!existAuto(hodnoty[1])) {
            if(FindMissingNumberA(Integer.valueOf(hodnoty[0]))<Integer.valueOf(hodnoty[0])) {
                ContentValues values = new ContentValues();
                values.put(KEY_ID_AUTO, FindMissingNumberA(Integer.valueOf(hodnoty[0])));
                values.put(KEY_NAZEV, hodnoty[1]);
                db.insert("auto", null, values);
            }
            else{
                ContentValues values = new ContentValues();
                values.put(KEY_ID_AUTO, hodnoty[0]);
                values.put(KEY_NAZEV, hodnoty[1]);
                db.insert("auto", null, values);
            }
        }
        //db.close();
    }

    public List<String> getAllZnacka(){
        List<String> list = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM auto", null);
        if(c!=null){
            c.moveToFirst();
        }
        do{
            String znacka = c.getString(1);
            list.add(znacka);
        }while(c.moveToNext());
        return list;
    }



    public String getZnacku(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            String znacka;
            String[] param = new String[]{valueOf(id)};
            Cursor c = db.rawQuery("SELECT nazev FROM auto where id_auto = '"+id+"'",null);
            if(c!=null){
                c.moveToFirst();
            }
            do{
                znacka = c.getString(0);
            }while(c.moveToNext());
            return znacka;
            /*Cursor cursor = db.query(DATABASE_TABLE_ZNACKY,
                    new String[]{KEY_ID_AUTO, KEY_NAZEV},
                    KEY_ID_AUTO + "=?", param,
                    null,
                    null,
                    null,
                    null);
            if (cursor != null) {
                cursor.moveToFirst();
            }
            String test = valueOf(cursor.getInt(1));

            return valueOf(cursor.getInt(1));*/
        } catch (Exception e) {
            String s = e.getMessage();
            int x;
            return "";
        }
    }

    public void editAuto(int id_nazvu, String text,String puvodninazev){
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        ContentValues valuesM = new ContentValues();
        values.put(KEY_ID_AUTO, id_nazvu);
        values.put(KEY_NAZEV, text);
        valuesM.put(KEY_ZNACKA, text);
        db.update(DATABASE_TABLE_AUTO,values,KEY_ID_AUTO+" = ? ",new String[]{String.valueOf(id_nazvu)});
        db.update(DATABASE_TABLE_MODEL,valuesM,KEY_ZNACKA+" = ? ",new String[]{String.valueOf(puvodninazev)});
        db.close();
    }

    //zjisti, jestli nekde nechybi id a opravi/prepise dane id
    public int FindMissingNumberA(int id){
        if(id !=1) { //pokud se nerovna 1 tak bude pokracovat jinak by funkce getPosledniIdAuta hodila null hodnotu a tim i chybu
            for (int i = 1; i < getPosledniIdAuta(false); i++) {
                    if(getZnacku(String.valueOf(i)) == "") { return i; }
            }
            return getPosledniIdAuta(true);
        }
        else{return 1;}
    }


    public boolean existAuto(String nazev){
        String znacka;
        try{
            SQLiteDatabase db = this.getReadableDatabase();
            for(int i = 1;i<getPosledniIdAuta(true);i++) {
                try{
                    znacka = getZnacku(String.valueOf(i));
                }
                catch(Exception ex){
                    znacka = "";
                }
                if(znacka.equals(nazev))
                {
                    return true;
                }
            }
        }catch (Exception e) {}
        return false;
    }

    public String existAutoID(String nazev){
        String znacka;
        try{
            SQLiteDatabase db = this.getReadableDatabase();
            for(int i = 1;i<getPosledniIdAuta(true);i++) {
                try{
                    znacka = getZnacku(String.valueOf(i));
                }
                catch(Exception ex){
                    znacka = "";
                }
                if(znacka.equals(nazev))
                {
                    return String.valueOf(i);
                }
            }
        }catch (Exception e) {}
        return "0";
    }

    public void smazZnackuAModel(int id_nazvu,String znacka){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("auto", KEY_ID_AUTO + "= ?", new String[] { String.valueOf(id_nazvu) });
        db.delete("model", KEY_ZNACKA + "= ?", new String[] { znacka });
        db.close();
    }

    public boolean existModel(String nazev){
        try{
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.query(DATABASE_TABLE_MODEL, new String[]{KEY_MODEL,
                            KEY_ZNACKA}, KEY_ZNACKA + "=?",
                    new String[]{valueOf(nazev)}, null, null, null, null);
            if(cursor!=null){
                return true;
            }
        }catch (Exception e) {}
        return false;
    }

    public void pridatModel(String[] hodnoty){
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_MODEL, hodnoty[0]);
        values.put(KEY_ZNACKA, hodnoty[1]);
        db.insert("model", null, values);
        db.close();
    }

    public List<String> GetAllModel(String znackad){
        List<String> list = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM model where znacka = '"+znackad+"'", null);
        if(c!=null){
            c.moveToFirst();
        }
        do{
            String model = c.getString(0);
            list.add(model);
        }while(c.moveToNext());
        return list;
    }

    public void DeleteModel(String znacka,String modelID){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("model", KEY_ZNACKA + "= ? AND "+KEY_MODEL +" = ?", new String[] { znacka,modelID });
        db.close();
    }

    public void editModel(String modelid,String znacka,String puvodnimodel, String puvodniznacka){
        db = this.getWritableDatabase();
        ContentValues valuesM = new ContentValues();
        valuesM.put(KEY_MODEL, modelid);
        valuesM.put(KEY_ZNACKA, znacka);
        db.update(DATABASE_TABLE_MODEL,valuesM,KEY_MODEL+" = ? AND "+KEY_ZNACKA+" = ?",new String[]{puvodnimodel,puvodniznacka});
        db.close();
    }
}
