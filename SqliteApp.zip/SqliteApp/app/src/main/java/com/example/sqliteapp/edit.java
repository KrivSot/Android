package com.example.sqliteapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class edit extends AppCompatActivity {

    int id;
    String auto;
    String znacka;
    String model;
    boolean modelu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit);
        Databaze db = new Databaze(this.getApplicationContext());
        Intent intent = getIntent();
        this.modelu = intent.getBooleanExtra("Modelt",true);
        Button edit = findViewById(R.id.EditButton1);
        edit.setOnClickListener(clickListener);
        EditText id = findViewById(R.id.AutoIDText);
        EditText name = findViewById(R.id.AutoText);
        if(!modelu) {
            this.auto = intent.getStringExtra("Auto");
            this.id = Integer.valueOf(db.existAutoID(auto));
            id.setText(String.valueOf(this.id));
            name.setText(String.valueOf(auto));
            db.close();
        }
        else{
            this.znacka = intent.getStringExtra("Znacka");
            this.model = intent.getStringExtra("Model");
            id.setText(intent.getStringExtra("Znacka"));
            name.setText(intent.getStringExtra("Model"));
        }
    }

    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            EditText name = findViewById(R.id.AutoText);
            EditText znackaE = findViewById(R.id.AutoIDText);
            Databaze db = new Databaze(getApplicationContext());
            if (!modelu) {
                if (!db.existAuto(String.valueOf(name.getText()))) {
                    db.editAuto(id, String.valueOf(name.getText()), auto);
                    db.close();
                    setResult(RESULT_OK);
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), "Auto už v databázi existuje!", Toast.LENGTH_SHORT).show();
                }
            }
            else{
                db.editModel(String.valueOf(name.getText()),String.valueOf(znackaE.getText()),model,znacka);
                db.close();
                setResult(RESULT_OK);
                finish();
            }
        }};

    public void Zrusit(View v)
    {
        this.finish();
    }
}
