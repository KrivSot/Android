package com.example.sqliteapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Znacky extends AppCompatActivity {

    String[] auto;
    String[] model;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.znacky_layout);
        ListView ls = findViewById(R.id.list);
        registerForContextMenu(ls);
        Databaze db = new Databaze(getApplicationContext());
        try {
            ArrayAdapter<String> aa = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,db.getAllZnacka());
            ls.setAdapter(aa);
        }
        catch (Exception e){
            auto = new String[] {"1","Skoda"};
            db.pridatAuto(auto);

            auto[0] = String.valueOf(db.getPosledniIdAuta(true));
            auto[1] = "VolkSwagen";
            db.pridatAuto(auto);
            auto[0] = String.valueOf(db.getPosledniIdAuta(true));
            auto[1] = "Dacia";
            db.pridatAuto(auto);

            model = new String[] {"Citigo","Skoda"};
            db.pridatModel(model);

            model = new String[] {"Fabia","Skoda"};
            db.pridatModel(model);

            model = new String[] {"Golf","VolkSwagen"};
            db.pridatModel(model);

            model = new String[] {"Brouk","VolkSwagen"};
            db.pridatModel(model);

            model = new String[] {"Sandero","Dacia"};
            db.pridatModel(model);

            model = new String[] {"Duster","Dacia"};
            db.pridatModel(model);

            ArrayAdapter<String> aa = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,db.getAllZnacka());
            ls.setAdapter(aa);
        }
        db.close();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if (v.getId()==R.id.list) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.menu_list, menu);
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
//        int cislo = Integer.valueOf((int) ((AdapterView.AdapterContextMenuInfo)info).id) +1;
        String key = ((TextView) info.targetView).getText().toString();
        Databaze db = new Databaze(getApplicationContext());
        switch(item.getItemId()) {
            case R.id.details:
                Intent details = new Intent(Znacky.this,Model.class);
                details.putExtra("Auto",key);
                startActivity(details);
                return true;
            case R.id.edit:
                Intent edit = new Intent(Znacky.this, edit.class);
                edit.putExtra("Auto", key);
                edit.putExtra("Modelt", false);
                startActivityForResult(edit,1);
                return true;
            case R.id.delete:
                db.smazZnackuAModel(Integer.valueOf(db.existAutoID(key)),key);
                ArrayAdapter<String> aa = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,db.getAllZnacka());
                ListView ls = findViewById(R.id.list);
                ls.setAdapter(aa);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }


    public void add(View v)
    {
        Intent pridatZnacky = new Intent(Znacky.this, add.class);
        pridatZnacky.putExtra("Auto",true);
        startActivityForResult(pridatZnacky,1);
    }

    public void edit(View v)
    {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)  {
        super.onActivityResult(requestCode, resultCode, data);
        Databaze db = new Databaze(getApplicationContext());
            ArrayAdapter<String> aa = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,db.getAllZnacka());
            ListView ls = findViewById(R.id.list);
            ls.setAdapter(aa);
        db.close();
    }
}
